import { Component, OnInit, Renderer2, Inject } from '@angular/core';
import { DOCUMENT } from '../../../../../node_modules/@angular/platform-browser';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  
  }

}
