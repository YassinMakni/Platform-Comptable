import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conseil-en-management',
  templateUrl: './conseil-en-management.component.html',
  styleUrls: ['./conseil-en-management.component.css']
})
export class ConseilEnManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
