import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conseil-en-transactions',
  templateUrl: './conseil-en-transactions.component.html',
  styleUrls: ['./conseil-en-transactions.component.css']
})
export class ConseilEnTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
