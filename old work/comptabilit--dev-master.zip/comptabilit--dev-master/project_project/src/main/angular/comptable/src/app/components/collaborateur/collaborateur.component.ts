import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collaborateur',
  templateUrl: './collaborateur.component.html',
  styleUrls: ['./collaborateur.component.css']
})
export class CollaborateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
