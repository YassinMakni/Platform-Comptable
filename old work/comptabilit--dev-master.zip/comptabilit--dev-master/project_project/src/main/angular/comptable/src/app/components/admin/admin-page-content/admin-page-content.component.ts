import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-page-content',
  templateUrl: './admin-page-content.component.html',
  styleUrls: ['./admin-page-content.component.css']
})
export class AdminPageContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
