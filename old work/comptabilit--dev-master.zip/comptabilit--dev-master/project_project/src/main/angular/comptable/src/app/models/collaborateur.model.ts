export class Collaborateur {
    public id: number;
    constructor(public nom: String, public prenom: String, public email: String, 
        public telephone: String, public motDePasse: String){}
}
