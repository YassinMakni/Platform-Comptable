import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-audit-et-certification',
  templateUrl: './audit-et-certification.component.html',
  styleUrls: ['./audit-et-certification.component.css']
})
export class AuditEtCertificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
