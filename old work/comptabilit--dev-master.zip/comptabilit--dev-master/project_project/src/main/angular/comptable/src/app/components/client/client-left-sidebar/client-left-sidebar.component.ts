import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-left-sidebar',
  templateUrl: './client-left-sidebar.component.html',
  styleUrls: ['./client-left-sidebar.component.css']
})
export class ClientLeftSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
