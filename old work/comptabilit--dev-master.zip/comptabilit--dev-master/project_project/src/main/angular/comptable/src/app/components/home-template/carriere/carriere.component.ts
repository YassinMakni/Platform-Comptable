import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carriere',
  templateUrl: './carriere.component.html',
  styleUrls: ['./carriere.component.css']
})
export class CarriereComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
