import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-page-content',
  templateUrl: './client-page-content.component.html',
  styleUrls: ['./client-page-content.component.css']
})
export class ClientPageContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
