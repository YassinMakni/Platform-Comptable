import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-collaborateur',
  templateUrl: './new-collaborateur.component.html',
  styleUrls: ['./new-collaborateur.component.css']
})
export class NewCollaborateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
