import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-collaborateur',
  templateUrl: './edit-collaborateur.component.html',
  styleUrls: ['./edit-collaborateur.component.css']
})
export class EditCollaborateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
