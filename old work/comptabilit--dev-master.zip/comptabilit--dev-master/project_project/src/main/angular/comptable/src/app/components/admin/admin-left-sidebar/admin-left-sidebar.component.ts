import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-left-sidebar',
  templateUrl: './admin-left-sidebar.component.html',
  styleUrls: ['./admin-left-sidebar.component.css']
})
export class AdminLeftSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
