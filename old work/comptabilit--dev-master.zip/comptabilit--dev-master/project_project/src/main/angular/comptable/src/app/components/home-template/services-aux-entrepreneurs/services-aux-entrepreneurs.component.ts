import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services-aux-entrepreneurs',
  templateUrl: './services-aux-entrepreneurs.component.html',
  styleUrls: ['./services-aux-entrepreneurs.component.css']
})
export class ServicesAuxEntrepreneursComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
