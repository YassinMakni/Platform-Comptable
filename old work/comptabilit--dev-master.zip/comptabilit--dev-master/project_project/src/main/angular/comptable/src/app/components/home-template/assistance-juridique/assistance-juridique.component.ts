import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assistance-juridique',
  templateUrl: './assistance-juridique.component.html',
  styleUrls: ['./assistance-juridique.component.css']
})
export class AssistanceJuridiqueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
