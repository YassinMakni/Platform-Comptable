import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-collaborateur',
  templateUrl: './profile-collaborateur.component.html',
  styleUrls: ['./profile-collaborateur.component.css']
})
export class ProfileCollaborateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
