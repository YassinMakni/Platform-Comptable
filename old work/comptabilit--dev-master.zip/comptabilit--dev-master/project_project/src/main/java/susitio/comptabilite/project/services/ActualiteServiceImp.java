package susitio.comptabilite.project.services;

import susitio.comptabilite.project.entities.Actualites;

import java.util.List;

public class ActualiteServiceImp implements ActualiteService {
    @Override
    public List<Actualites> getAcualites() {
        return getAcualites() ;
    }

    @Override
    public Actualites getActualliteById(int id) {
        return getActualliteById(id);
    }
}
