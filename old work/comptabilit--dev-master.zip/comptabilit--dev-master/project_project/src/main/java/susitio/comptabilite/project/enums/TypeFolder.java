package susitio.comptabilite.project.enums;

public enum TypeFolder {
	actualite,
	convention,
	dossierJuridique,
	dossierAnnuel,
	Janvier,
	Février,
	Mars,	
	Avril,	
	Mai,	
	Juin,	
	Juillet,	
	Août,
	Septembrer,	
	Octobre,	
	Novembre,	
	Décembre
}
