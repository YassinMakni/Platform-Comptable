package susitio.comptabilite.project.enums;

public enum TypeNotification {
    message,
    document,
    payement
}
