package susitio.comptabilite.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import susitio.comptabilite.project.entities.Role;

public interface RoleRepository extends JpaRepository<Role,Integer>{

}
